import { useState } from 'react'

import './App.css'

function App() {
  return (
    <>
      <h1>Hehe</h1>
    </>
  )
}

export default App
