import { Container, Box, Typography } from '@mui/material';

function Home() {
  return (
    <Container>
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" align="center" gutterBottom sx={{ mt: 4 }}>
          HOME
        </Typography>
      </Box>
    </Container>
  );
}

export default Home;
