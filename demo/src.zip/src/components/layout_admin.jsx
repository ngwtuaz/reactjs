function Admin() {
    return (
        <>
            <h1>Admin</h1>
        </>
    )
}

export default Admin;