function PageHeader() {
    // let style = {
    //     color: "blue",
    //     backgroundColor: "red",
    // }
    return (
        <>
            <h1 /*style={style}*/>Page header</h1>
        </>
    );
}

export default PageHeader;