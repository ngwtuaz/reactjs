import NewItem from "./new_item";

function ListNew() {
    return (
        <>
            <h1>List New</h1>
            <NewItem />
        </>
    );
}

export default ListNew;