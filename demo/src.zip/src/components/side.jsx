import ListNew from "./list_new";
import RegisterForm from "./register_form";

function PageAside() {
    return (
        <>
            <h1>PageAside</h1>
            <RegisterForm />
            <ListNew/>
        </>
    );
}

export default PageAside;