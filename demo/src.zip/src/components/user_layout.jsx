import { Outlet } from "react-router-dom";
import ResponsiveAppBar from "./header_app";
import ColorInversionFooter from "./footer_app";

function UserLayout() {
    return (
        <>
            <ResponsiveAppBar />
            <main>
                <Outlet />
            </main>
            <ColorInversionFooter />
        </>
    );
}
export default UserLayout;