import Content from './Content'
const App = () => {
  return (
    <div className='flex bg-[#c2d5a6] min-h-screen'>
      <Content></Content>
    </div>
  );
};

export default App;